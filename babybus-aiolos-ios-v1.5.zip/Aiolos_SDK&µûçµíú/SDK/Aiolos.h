//
//  Aiolos.h
//  Aiolos
//
//  Created by 马永成 on 2017/8/23.
//  Copyright © 2017年 马永成. All rights reserved.
//

#import <Foundation/Foundation.h>

#define AiolosConfigShared [AiolosConfig sharedConfig]

@interface AiolosConfig : NSObject
@property(nonatomic, copy) NSString *appKey;
@property(nonatomic, copy) NSString *channelId; //默认"AppleStore"
@property(nonatomic) BOOL isDebugModel;  //调试模式，默认NO, 目前请无视它
@property(nonatomic) BOOL showLog; //显示日志，默认NO
+ (instancetype)sharedConfig;
@end

@interface Aiolos : NSObject

/**
 根据配置启动Aiolos
 
 @param config Aiolos相关配置
 */
+ (void)startWithAiolosConfig:(AiolosConfig *)config;

/**
 *  记录计数事件
 
 *  @param event_id 事件ID
 */
+ (void)recordEvent:(NSString *)event_id;

/**
 记录计数事件
 
 @param event_id 事件ID
 @param v1 参数1
 */
+ (void)recordEvent:(NSString *)event_id value1:(NSString *)v1;


/**
 记录计数事件
 
 @param event_id 事件ID
 @param v1 参数1
 @param v2 参数2
 */
+ (void)recordEvent:(NSString *)event_id value1:(NSString *)v1 value2:(NSString *)v2;

/**
 *  开始计时事件
 
 *  @param event_id 事件ID
 */
+ (void)startEvent:(NSString*)event_id;


/**
 开始计时事件
 
 @param event_id 事件ID
 @param v1 参数1
 */
+ (void)startEvent:(NSString*)event_id value1:(NSString *)v1;


/**
 开始计时事件
 
 @param event_id 事件ID
 @param v1 参数1
 @param v2 参数2
 */
+ (void)startEvent:(NSString*)event_id value1:(NSString *)v1 value2:(NSString *)v2;

/**
 *  结束计时事件
 
 *  @param event_id 事件ID
 */
+ (void)endEvent:(NSString*)event_id;

/**
 *  获取设备ID
 *
 */
+ (NSString *)getDeviceid;

/**
 *  获取App上次使用时长
 *
 */
+ (int)getAppLastUseDuration;

@end
